# bankingMangement

# Some of the functionalities that are working still need some extra work regarding error handling and extra validation. Unfortunately time became an issue and led to spending time on formatting and error handling to become second priority to getting the functionality of the system working. 
# If there was to be a version 2 more thought would go into these aspects and re-working what is currently working to a better standard.